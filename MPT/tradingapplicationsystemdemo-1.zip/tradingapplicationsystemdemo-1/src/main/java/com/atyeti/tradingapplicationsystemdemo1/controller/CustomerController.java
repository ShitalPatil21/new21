package com.atyeti.tradingapplicationsystemdemo1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.atyeti.tradingapplicationsystemdemo1.beans.CustomerBean;
import com.atyeti.tradingapplicationsystemdemo1.beans.TradingResponseBean;
import com.atyeti.tradingapplicationsystemdemo1.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;
	String success = "success";
	@PostMapping("/userRegistration")
	public TradingResponseBean registerUser(@RequestBody CustomerBean customerBean) {
		TradingResponseBean tradingResponseBean = new TradingResponseBean();
	customerService.registration(customerBean);
		tradingResponseBean.setStatusCode(200);
		tradingResponseBean.setMessage("success");
		tradingResponseBean.setDescription("User Register Successfully");
		return tradingResponseBean;
	}// end of add User
}
