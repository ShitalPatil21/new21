package com.atyeti.tradingapplicationsystemdemo1.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.atyeti.tradingapplicationsystemdemo1.beans.CustomerBean;
@Repository

public class CustomerDaoImpl implements CustomerDao{
	@Autowired
	EntityManagerFactory entityManagerFactory;

	@Override
	
	public void registration(CustomerBean customerBean) {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		try {
			entityTransaction.begin();
			entityManager.persist(customerBean);
			entityTransaction.commit();
			
		} catch (Exception e) {
			entityTransaction.rollback();
			e.printStackTrace();
		}
		
	}

}
