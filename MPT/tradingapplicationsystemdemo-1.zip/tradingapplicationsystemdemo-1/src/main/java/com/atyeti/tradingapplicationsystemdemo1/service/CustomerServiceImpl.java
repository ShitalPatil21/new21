package com.atyeti.tradingapplicationsystemdemo1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atyeti.tradingapplicationsystemdemo1.beans.CustomerBean;
import com.atyeti.tradingapplicationsystemdemo1.dao.CustomerDao;
@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDao customerDao;
	@Override
	public void registration(CustomerBean customerBean) {
		
		customerDao.registration(customerBean);
	}

}
